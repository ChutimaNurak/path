<!-- pdf.blade.php -->

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <table class="table table-bordered">
      <tr>
        <td>
          {{$user->Latitude}}
        </td>
        <td>
          {{$user->Longitude}}
        </td>
      </tr>
      <tr>
        <td>
          {{$user->Sequence}}
        </td>
        <td>
