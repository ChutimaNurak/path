<?php $__env->startSection('content'); ?>

<?php
	float number[i], minValue[j];
	int i=0, j=0;
	if(number[i] < minValue[j])
	{
		minValue[j] = number[i];
		number[i-1];
		minValue[j+1];
		i++;

			if(number[i]==0)
			{
				if(number[i] < minValue[j])
				{
					minValue[j] = number[i];
					number[i-1];
					minValue[j+1];
					i++;
				}else
					i++;
				}		
		}else
			minValue[j];
			print_r($minValue);
	}else
		i++;
	}
?>
<div class="container">
	asdasdasd
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>