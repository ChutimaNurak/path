<?php $__env->startSection('content'); ?>

<?php $__empty_1 = true; $__currentLoopData = $table_customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 

<style type="text/css">
	h3{
		text-align: center!important;
	}
</style>
<br>
<h3>รหัสลูกค้า <?php echo e($row->ID); ?></h3>

<div class="col-md-offset-2 col-md-8">
	<div class="x_panel">
		<form action="<?php echo e(url('/')); ?>/customer/<?php echo e($row->ID); ?>" method="POST"> 
			<?php echo e(csrf_field()); ?> 
			<?php echo e(method_field('PUT')); ?> 
			<div class="line"> 
				<strong>ชื่อ - นามสกุล : </strong> 
				<input class="form-control" type="text" name="Name"  value="<?php echo e($row->Name); ?>"> 
			</div> 
		<br>
			<div class="line"> 
				<strong>เบอร์โทร : </strong> 
				<input class="form-control" type="text" data-masked-input="999-9999999" 
						pattern="[0-9]{3}-[0-9]{7}" maxlength="11" name="Telephone" value="<?php echo e($row->Telephone); ?>"> 
			</div> 
		<br>
			<div class="line"> 
				<strong>อีเมลล์ : </strong> 
				<input class="form-control" type="Email" name="Email" value="<?php echo e($row->Email); ?>"> 
			</div> 
		<br>
			<div class="line">
				<a href="<?php echo e(url('/')); ?>/customer" class="btn btn-primary pull-right">Back</a>
				<button type="submit" class="btn btn-outline btn-warning" >Update</button> 
			</div>
		</form>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>