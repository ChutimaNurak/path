<?php $__env->startSection('content'); ?>
<style type="text/css">
	table {
		width:80%;
	}
	th {
		text-align: center!important;
	}
	td {
		text-align: center!important;
	}
</style>
<br>
<h1 style="text-align: center!important">รายละเอียดข้อมูลเส้นทาง</h1>
	<div class="line"> 
		<form class="inline" action="<?php echo e(url('/')); ?>/route" method="GET"> 
			<input type="text" name="q" placeholder="ระบุชื่อ - นามสกุล" value="<?php echo e($q); ?>"> 
			<button type="submit">ค้นหา</button> 
		</form> 
	</div>
<br>
<table border=1>
	<tr>
		<th>รหัสเส้นทาง</th>
		<th>รหัสรอบงาน</th>
		<th>รหัสตำแหน่ง</th>
		<th>ลำดับที่</th>
		<th>ระยะทาง</th>
		<th>action</th>
	</tr>
	<?php $__currentLoopData = $table_route; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($row->ID_Route); ?> </td>
		<td><?php echo e($row->ID_Job); ?></td>
		<td><?php echo e($row->ID_Position); ?></td>
		<td><?php echo e($row->Sequence); ?> </td>
		<td><?php echo e($row->District); ?> </td>
		<td>
			<form class="inline" action="<?php echo e(url('/')); ?>/route/<?php echo e($row->ID_Route); ?>" method="POST"> 
			<?php echo e(csrf_field()); ?> 
			<?php echo e(method_field('DELETE')); ?> 
			<button type="submit">Delete</button> 
			<button><a href="<?php echo e(url('/')); ?>/route/<?php echo e($row->ID_Route); ?>/edit">edit</a></button>
			<button><a href="<?php echo e(url('/')); ?>/route/<?php echo e($row->ID_Route); ?>">Viwe</a></button>
			</form>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>