<?php $__env->startSection('content'); ?>

<style type="text/css">
	table {
		width:100%;
	}
	h1{
		text-align: center!important;
	}
</style>

<br>
<!-- เพิ่มข้อมูลรอบงาน -->
<a href="<?php echo e(url('/')); ?>/job/create" class="btn btn-warning pull-right">เพิ่มข้อมูลรอบงาน</a>
<br>

<!-- หัวเรื่อง -->
<h1>รายละเอียดข้อมูลรอบงาน</h1>
<br>

<!-- ค้นหา -->
	<div class="line" style="text-align: center!important" class="btn btn-warnin" > 
		<form class="inline" action="<?php echo e(url('/')); ?>/job" method="GET"  > 
			<input type="text" name="q" placeholder="ระบุชื่อรอบงาน" value="<?php echo e($q); ?>" > 
			<button class="btn btn-default" type="submit">
                        <i class="fa fa-search"></i>
                    </button>
		</form> 
	</div>
<br><br>

<!-- ตาราง -->
<table class="table">
	<tr>
		<!-- <th style="text-align: center!important;">รหัสรอบงาน</th> -->
		<th></th>
		<th>ชื่อรอบงาน</th>
		<th style="text-align: center!important;">ปี/เดือน/วัน และเวลา ที่เพิ่มรอบงาน</th>
		<th style="text-align: center!important;">ระยะทางรวม (กิโลเมตร)</th>
		<th style="text-align: center!important;">เวลารวม (ชั่วโมง)</th>
		<th></th>
	</tr>
	<?php $__currentLoopData = $table_job; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<!-- <td style="text-align: center!important;"><?php echo e($row->ID_Job); ?> </td> -->
		<td></td>
		<td><?php echo e($row->Name_Job); ?> </td>
		<td style="text-align: center!important;"><?php echo e($row->Date); ?></td>
		<td style="text-align: center!important;"><?php echo e($row->Distance_Sum); ?></td>
		<td style="text-align: center!important;"><?php echo e($row->Time_Sum); ?></td>
		<td style="text-align: center!important;">
			<form class="inline" action="<?php echo e(url('/')); ?>/job/<?php echo e($row->ID_Job); ?>" method="POST"> 
			<?php echo e(csrf_field()); ?> 
			<?php echo e(method_field('DELETE')); ?> 						
			<a href="<?php echo e(url('/')); ?>/job/<?php echo e($row->ID_Job); ?>" class="btn btn-outline btn-primary">View</a>
			<a href="<?php echo e(url('/')); ?>/job/<?php echo e($row->ID_Job); ?>/edit" class="btn btn-outline btn-success">edit</a>
			<button type="submit" class="btn btn-danger">Delete</button> 
		</form>
	</tr>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>