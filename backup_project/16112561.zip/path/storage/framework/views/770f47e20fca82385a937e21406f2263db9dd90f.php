<?php $__env->startSection('content'); ?>
<?php $__empty_1 = true; $__currentLoopData = $table_job; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 

<style type="text/css">
	h2{
		text-align: center!important;
	}
</style>
<br>

<h2>แก้ไขข้อมูลรอบงานที่ <?php echo e($row->ID_Job); ?></h2> 
<br> 
<div class="col-md-offset-2 col-md-8">
	<div class="x_panel">
		<form action="<?php echo e(url('/')); ?>/job/<?php echo e($row->ID_Job); ?>" method="POST"> 
			<?php echo e(csrf_field()); ?> 
			<?php echo e(method_field('PUT')); ?> 
			<div class="line"> 
				<strong>ชื่อรอบงาน : </strong> 
				<input class="form-control" type="text" name="Name_Job"  value="<?php echo e($row-> Name_Job); ?>"> 
			</div> 
		<br>
			<div class="line"> 
				<strong>ปี/เดือน/วัน และเวลา : </strong> 
				<input class="form-control" type="text" name="Date"  value="<?php echo e($row->Date); ?>"> 
			</div> 
		<br>
			<div class="line"> 
				<strong>ระยะทางรวม : </strong> 
				<input  class="form-control" type="number" name="Distance_Sum" value="<?php echo e($row-> Distance_Sum); ?>"> 
			</div> 
		<br>
			<div class="line"> 
				<strong>เวลารวม : </strong> 
				<input  class="form-control" type="number" name="Time_Sum" value="<?php echo e($row->Time_Sum); ?>"> 
			</div> 
		<br>
			<div class="line">
				<a href="<?php echo e(url('/')); ?>/job"  class="btn btn-primary pull-right">back</a>
				<button type="submit" class="btn btn-outline btn-warning">Update</button> 
			</div>
		</form>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>