<?php $__env->startSection('content'); ?>
<style type="text/css">
	table {
		width:100%;
	}
	th {
		text-align: center!important;
	}
</style>
<br><h1>รายละเอียดข้อมูลที่อยู่ลูกค้า</h1>
	<div class="line" > 
		<form class="inline" action="<?php echo e(url('/')); ?>/position" method="GET"> 
			<input type="text" name="q" placeholder="ระบุรหัสไปรษณีย์" value="<?php echo e($q); ?>"> 
			<button type="submit">ค้นหา</button> 
		</form> 
	</div>

<table border=1>
	<tr>
		<th>รหัสตำแหน่ง</th>
		<th>รหัสลูกค้า</th>
		<th>บ้านเลขที่</th>
		<th>หมู่ที่</th>
		<th>ตำบล</th>
		<th>อำเภอ</th>
		<th>จังหวัด</th>
		<th>รหัสไปรษณีย์</th>
		<th>ละติจูด</th>
		<th>ลองจิจูด</th>
		<th>action</th>
	</tr>
	<?php $__currentLoopData = $table_position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($row->ID_Position); ?> </td>
		<td><?php echo e($row->ID); ?></td>
		<td><?php echo e($row->House_number); ?></td>
		<td><?php echo e($row->Village); ?> </td>
		<td><?php echo e($row->District); ?></td>
		<td><?php echo e($row->City); ?></td>
		<td><?php echo e($row->Province); ?></td>
		<td><?php echo e($row->Zip_code); ?></td>
		<td><?php echo e($row->Latitude); ?></td>
		<td><?php echo e($row->Longitude); ?></td>
		<td>
			<form class="inline" action="<?php echo e(url('/')); ?>/position/<?php echo e($row->ID_Position); ?>" method="POST"> 
			<?php echo e(csrf_field()); ?> 
			<?php echo e(method_field('DELETE')); ?> 
			<button type="submit">Delete</button> 
			<button><a href="<?php echo e(url('/')); ?>/position/<?php echo e($row->ID_Position); ?>/edit">edit</a></button>
			<button><a href="<?php echo e(url('/')); ?>/position/<?php echo e($row->ID_Position); ?>">Viwe</a></button>
			</form>
		</td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>