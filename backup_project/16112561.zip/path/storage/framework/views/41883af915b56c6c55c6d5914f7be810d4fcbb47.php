<?php $__env->startSection('content'); ?>
<?php $__empty_1 = true; $__currentLoopData = $table_customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 

<style type="text/css">
	table {
		width:100%;
	}
	h2 {
		text-align: center!important;
	}
</style>
<br>
<!-- ข้อมูลลูกค้า -->
	<div div class="line">
		<strong>รหัสลูกค้า</strong> 
		<span><?php echo e($row->ID); ?></span>
	</div>
	<div class="line"> 
		<strong>ชื่อ - นามสกุล : </strong> 
		<span><?php echo e($row->Name); ?></span> 
	</div> 
	<div class="line"> 
		<strong>เบอร์โทร : </strong> 
		<span><?php echo e($row->Telephone); ?></span> 
	</div> 
	<div class="line"> 
		<strong>อีเมลล์ : </strong> 
		<span><?php echo e($row->Email); ?></span> 
	</div> 
	<div class="line"> 
			<a href="<?php echo e(url('/')); ?>/position/create?ID=<?php echo e($row->ID); ?>" class="btn btn-warning"> เพิ่มข้อมูลที่อยู่ลูกค้า </a>
			<a href="<?php echo e(url('/')); ?>/customer" class="btn btn-primary">back</a>
	</div> 

<h2>ข้อมูลที่อยู่ของ <?php echo e($row->Name); ?> </h2>
<br>

<!-- ตาราง -->
<table class="table">
	<tr>
		<th></th>
		<!-- <th>รหัสตำแหน่ง</th> -->
		<th style="text-align: center!important";>บ้านเลขที่</th>
		<th style="text-align: center!important;">หมู่ที่</th>
		<th>ตำบล</th>
		<th>อำเภอ</th>
		<th>จังหวัด</th>
		<th style="text-align: center!important;">รหัสไปรษณีย์</th>
		<th style="text-align: center!important;">ละจิจูด</th>
		<th style="text-align: center!important;">ลองจิจูด</th>
		<th></th>
	</tr>
	<?php $__currentLoopData = $table_position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td></td>
		<!-- <td style="text-align: center!important;"><?php echo e($row->ID_Position); ?> </td> -->
		<td style="text-align: center!important;"><?php echo e($row->House_number); ?></td>
		<td style="text-align: center!important;"><?php echo e($row->Village); ?> </td>
		<td><?php echo e($row->District); ?></td>
		<td><?php echo e($row->City); ?></td>
		<td><?php echo e($row->Province); ?></td>
		<td style="text-align: center!important;"><?php echo e($row->Zip_code); ?></td>
		<td style="text-align: center!important;"><?php echo e($row->Latitude); ?></td>
		<td style="text-align: center!important;"><?php echo e($row->Longitude); ?></td>
		<td style="text-align: center!important;">
			<form class="inline" action="<?php echo e(url('/')); ?>/position/<?php echo e($row->ID_Position); ?>?ID=<?php echo e($row->ID); ?>" method="POST"> 
			<?php echo e(csrf_field()); ?> 
			<?php echo e(method_field('DELETE')); ?> 
			<a href="<?php echo e(url('/')); ?>/position/<?php echo e($row->ID_Position); ?>/edit"class="btn btn-outline btn-success">edit</a>
			<button type="submit" class="btn btn-danger">Delete</button> 
			
			</form>
		</td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
	<div>This Customer id does not exist</div>
 <?php endif; ?>
 <?php $__env->stopSection(); ?>



<?php echo $__env->make('theme.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>