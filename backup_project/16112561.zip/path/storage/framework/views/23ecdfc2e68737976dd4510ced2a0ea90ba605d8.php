<?php $__env->startSection('content'); ?>

<style type="text/css">
	table {
		width:100%;
	}
	h1{
		text-align: center!important
	}
</style>

<br>
<!-- เพิ่มข้อมูลลูกค้า -->
<a href="<?php echo e(url('/')); ?>/customer/create" class="btn btn-warning pull-right">เพิ่มข้อมูลลูกค้า</a> 
<br>

<h1>รายละเอียดข้อมูลลูกค้า</h1>
<br>

<!-- ค้นหา -->
	<div class="line" style="text-align: center!important"> 
		<form class="inline" action="<?php echo e(url('/')); ?>/customer" method="GET"> 
			<input type="text" name="q" placeholder="ระบุชื่อ-นามสกุล" value="<?php echo e($q); ?>"> 
                    <button class="btn btn-default" type="submit">
                        <i class="fa fa-search"></i>
		</form> 
	</div>
		<br>
		<br>
<!-- ตาราง -->
		<table class="table">
			<tr>
				<!-- <th style="text-align: center!important;">รหัสลูกค้า</th> -->
				<th></th>
				<th>ชื่อ-นามสกุล</th>
				<th>เบอร์โทร</th>
				<th>อีเมลล์</th>
				<th></th>
			</tr>
			<?php $__currentLoopData = $table_customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td></td>
				<!-- <td style="text-align: center!important"><?php echo e($row->ID); ?> </td> -->
				<td><?php echo e($row->Name); ?></td>
				<td><?php echo e($row->Telephone); ?></td>
				<td><?php echo e($row->Email); ?> </td>
				<td style="text-align: center!important">
					<form class="inline" action="<?php echo e(url('/')); ?>/customer/<?php echo e($row->ID); ?>" method="POST"> 
					<?php echo e(csrf_field()); ?> 
					<?php echo e(method_field('DELETE')); ?> 
					<a href="<?php echo e(url('/')); ?>/customer/<?php echo e($row->ID); ?>" class="btn btn-outline btn-primary">View</a>
					<a href="<?php echo e(url('/')); ?>/customer/<?php echo e($row->ID); ?>/edit" class="btn btn-outline btn-success">edit</a>
					<button type="submit" class="btn btn-danger">Delete</button> 
					</form>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>