<?php $__env->startSection('content'); ?>
<br>
<h2 style="text-align: center!important;">เพิ่มข้อมูลรอบงาน</h2>
<div class="col-md-offset-2 col-md-8">
	<div class="x_panel">
		<form action="<?php echo e(url('/')); ?>/job" method="POST">
			<?php echo e(csrf_field()); ?>

			<?php echo e(method_field('POST')); ?>

			<br>

			<div class="line">
				<strong>ชื่อรอบงาน :</strong>
				<input class="form-control" type="text" name="Name_Job" placeholder="ระบุชื่อรอบงาน" required >
			</div>
			<br>

			<div class="line">
				<a href="<?php echo e(url('/')); ?>/job"  class="btn btn-primary pull-right">back</a>
				<button type="submit" class="btn btn-warning">Create</button>
			</div>
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>