<?php $__env->startSection('content'); ?>

<?php $__empty_1 = true; $__currentLoopData = $table_route; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
<h2>รหัสเส้นทาง : <?php echo e($row->ID_Route); ?> </h2> 
 
	<div class="line"> 
		<strong>รหัสเส้นทาง : </strong> 
		<span><?php echo e($row->ID_Route); ?></span> 
	</div> 
	<div class="line"> 
		<strong>รหัสรอบงาน : </strong> 
		<span><?php echo e($row->ID_Job); ?></span> 
	</div> 
	<div class="line"> 
		<strong>รหัสตำแหน่ง : </strong> 
		<span><?php echo e($row->ID_Position); ?></span> 
	</div> 
	<div class="line"> 
		<strong>ลำดับที่ : </strong> 
		<span><?php echo e($row->Sequence); ?></span> 
	</div> 
	<div class="line"> 
		<strong>ระยะทาง : </strong> 
		<span><?php echo e($row->District); ?></span> 
	</div> 
	
	<div class="line"> 
			<button><a href="<?php echo e(url('/')); ?>/route">back</a></button>
	</div> 
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
	<div>This Route id does not exist</div>
 <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>