<?php $__env->startSection('content'); ?>

<?php $__empty_1 = true; $__currentLoopData = $table_position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
<h2>รหัสตำแหน่ง : <?php echo e($row->ID_Position); ?> </h2> 
	<div class="line"> 
		<strong>รหัสลูกค้า : </strong> 
		<span><?php echo e($row->ID); ?> </span> 
	</div> 
	<div class="line"> 
		<strong>บ้านเลขที่ : </strong> 
		<span><?php echo e($row->House_number); ?></span> 
	</div> 
	<div class="line"> 
		<strong>หมู่ที่ : </strong> 
		<span><?php echo e($row->Village); ?></span> 
	</div> 
	<div class="line"> 
		<strong>ตำบล : </strong> 
		<span><?php echo e($row->District); ?></span> 
	</div> 
	<div class="line"> 
		<strong>อำเภอ : </strong> 
		<span><?php echo e($row->City); ?> </span> 
	</div> 
	<div class="line"> 
		<strong>จังหวัด : </strong> 
		<span><?php echo e($row->Province); ?></span> 
	</div> 
	<div class="line"> 
		<strong>รหัสไปรษณีย์ : </strong> 
		<span><?php echo e($row->Zip_code); ?></span> 
	</div> 
	<div class="line"> 
		<strong>ละจิจูด : </strong> 
		<span><?php echo e($row->Latitude); ?></span> 
	</div> 
	<div class="line"> 
		<strong>ลองจิจูด : </strong> 
		<span><?php echo e($row->Longitude); ?></span> 
	</div> 
	<div class="line"> 
			<button><a href="<?php echo e(url('/')); ?>/customer/<?php echo e($row->ID); ?>">back</a></button>
	</div> 
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
	<div>This Position ID_Position does not exist</div>
 <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>