<?php $__env->startSection('content'); ?>

<h2 style="text-align: center!important">เพิ่มข้อมูลเส้นทาง</h2>
<form action="<?php echo e(url('/')); ?>/route" method="POST">
	<?php echo e(csrf_field()); ?>

	<?php echo e(method_field('POST')); ?>

	
	<br>
	<div class="line">
		<strong>รหัสรอบงาน :</strong>
		<input class="form-control type="number" name="ID_Job" value="<?php echo e($ID_Job); ?>" readonly >
	</div>
	
	<br>
	<div class="line">
		<strong >ตำแหน่ง : </strong>
		<!--<input type="number" name="ID_Position" placeholder="ระบุรหัสตำแหน่ง" >-->
		<select name="ID_Position" class="form-control">
			<?php $__currentLoopData = $table_position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($row_position->ID_Position); ?>">
			<?php echo e($row_position->Name_Position); ?>

			</option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>	
	</div>	
	
	<br>
	<div class="line">
		<a href="<?php echo e(url('/')); ?>/job/<?php echo e($ID_Job); ?>" class="btn btn-primary pull-right" >back</a>
		<button type="submit" class="btn btn-warning btn-success">Create</button>
	</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>