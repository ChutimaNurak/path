<?php $__env->startSection('content'); ?>

<?php $__empty_1 = true; $__currentLoopData = $table_job; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 

<style>
	#map {
			height: 500px;
			width: 1050px;
			}
	h2{
		text-align: center!important;
	}
	.button5 {
    background-color: white;
    color: black;
    border: 2px solid #555555;
	}

	.button5:hover {
	    background-color: #555555;
	    color: white;
	}
</style>
<br>
	<button onclick="window.print()" class="button button5 pull-right hidden-print" >พิมพ์รายงาน</button>
	<br>
	<div class="line"> 
		<strong>รหัสรอบงาน : </strong> 
		<span><?php echo e($row->ID_Job); ?></span> 
	</div> 
	<div class="line"> 
		<strong>ปี/เดือน/วัน และเวลา : </strong> 
		<span><?php echo e($row->Date); ?></span> 
	</div> 
	<div class="line"> 
		<strong>ระยะทางรวม : </strong> 
		<span><?php echo e($row->Distance_Sum); ?></span> 
	</div> 
	<div class="line"> 
		<strong>ระยะเวลารวม : </strong> 
		<span><?php echo e($row->Time_Sum); ?></span> 
	</div> 
		<div class="line"> 
			<a href="<?php echo e(url('/')); ?>/route/create?ID_Job=<?php echo e($ID_Job); ?>" class="btn btn-warning hidden-print"> เพิ่มข้อมูลเส้นทาง </a>
			<a href="<?php echo e(url('/')); ?>/job" class="btn btn-primary hidden-print ">back</a>
	</div> 

<br>
<h2>รอบงาน <?php echo e($row->Name_Job); ?> </h2>
<br>
	<table class="table">
		<tr>
			<!-- <th style="text-align: center!important;">รหัสเส้นทาง</th> -->
			<th>ชื่อ - นามสกุล</th>
			<th>ตำแหน่ง</th>
			<th style="text-align: center!important;">ละติจูด</th>
			<th style="text-align: center!important;">ลองจิจูด</th>
			<th style="text-align: center!important;">ลำดับที่</th>
			<th style="text-align: center!important;">ระยะทาง</th>
			<th style="text-align: center!important;">เวลา</th>
			<th></th>
		</tr>
		<?php $__currentLoopData = $table_route; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<!-- <td style="text-align: center!important;"><?php echo e($row->ID_Route); ?> </td> -->
			<td><?php echo e($row->Name); ?></td>
			<td><?php echo e($row->Province); ?> </td>
			<td style="text-align: center!important;"><?php echo e($row->Latitude); ?> </td>
			<td style="text-align: center!important;"><?php echo e($row->Longitude); ?> </td>
			<td style="text-align: center!important;"><?php echo e($row->Sequence); ?> </td>
			<td id="dis" style="text-align: center!important;" ><?php echo e($row->District); ?> </td>
			<td style="text-align: center!important;"><?php echo e($row->Time); ?></td>
			<td style="text-align: center!important;">
				<form class="inline" action="<?php echo e(url('/')); ?>/route/<?php echo e($row->ID_Route); ?>?ID_Job=<?php echo e($ID_Job); ?>" method="POST"> 
				<?php echo e(csrf_field()); ?> 
				<?php echo e(method_field('DELETE')); ?> 
				<a href="<?php echo e(url('/')); ?>/route/<?php echo e($row->ID_Route); ?>/edit" class="btn btn-outline btn-success hidden-print">edit</a>
				<button type="submit" class="btn btn-danger hidden-print">Delete</button> 
				</form>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>

<!-- หาเส้นทาง -->
<a href="<?php echo e(url('/')); ?>/route/dis/<?php echo e($row->ID_Job); ?>" class="btn btn-primary hidden-print">คำนวนเส้นทาง</a>
<br>
<br>

<!-- googlge map -->

<div id="map"></div>
	<script>
		var map;
		//console.log(dis);
		function initMap() {
		var mapOptions = {
			center: {lat: 13.847860, lng: 100.604274},
			zoom: 18,
			}
			 
		var maps = new google.maps.Map(document.getElementById("map"),mapOptions);
		var marker = new google.maps.Marker({
			position: new google.maps.LatLng(13.847616, 100.604736),map: maps,
						title: 'ถนน ลาดปลาเค้า',icon: 'images/camping-icon.png', 
			});

		var info = new google.maps.InfoWindow({
			content : '<div style="font-size: 25px;color: red">ThaiCreate.Com Camping</div>'
			});

			google.maps.event.addListener(marker, 'click', function() {
			nfo.open(maps, marker);
			});
		}

	</script>
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC6EpDuzLcc5fhxZfr30n4eNoHOQQGLlTY&libraries=places&callback=initMap"async defer></script>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>