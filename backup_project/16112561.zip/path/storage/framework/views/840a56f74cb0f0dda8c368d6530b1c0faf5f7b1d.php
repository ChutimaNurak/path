<?php $__env->startSection('content'); ?>
<?php $__empty_1 = true; $__currentLoopData = $table_route; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 

<style type="text/css">
	h2{
		text-align: center!important;
	}
</style>
<br>

	<h2>แก้ไขข้อมูลเส้นทางที่ <?php echo e($row->ID_Route); ?></h2> 
	<form action="<?php echo e(url('/')); ?>/route/<?php echo e($row->ID_Route); ?>" method="POST"> 
		<?php echo e(csrf_field()); ?> 
		<?php echo e(method_field('PUT')); ?> 

		<div class="line"> 
			<strong>รหัสรอบงาน : </strong> 
			<input class="form-control" type="text" name="ID_Job"  value="<?php echo e($row->ID_Job); ?>" readonly> 
		</div> 
		<br>

		<div class="line"> 
			<strong>ตำแหน่ง : </strong> 
			<!-- <input type="text" name="ID_Position" value="<?php echo e($row->ID_Position); ?>">  -->
			<select name="ID_Position" class="form-control"  >
				<?php $__currentLoopData = $table_position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($row_position->ID_Position); ?>"
						<?php echo e($row_position->ID_Position === $row->ID_Position ? "selected" : ""); ?> >
						<?php echo e($row_position->Name_Position); ?>

				</option>
            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div> 
		<br>

		<div class="line"> 
			<strong>ลำดับที่ : </strong> 
			<input class="form-control"  type="text" name="Sequence" value="<?php echo e($row->Sequence); ?>"> 
		</div> 
		<br>

		<div class="line"> 
			<strong>ระยะทาง : </strong> 
			<input class="form-control"  type="text" name="District" value="<?php echo e($row->District); ?>"> 
		</div>
		<br>

		<div class="line"> 
			<strong>เวลา : </strong> 
			<input class="form-control"  type="text" name="Time" value="<?php echo e($row->Time); ?>"> 
		</div>
		<br>

		<div class="line">
			<a href="<?php echo e(url('/')); ?>/job/<?php echo e($row->ID_Job); ?>" class="btn btn-primary pull-right ">back</a>
			<button type="submit" class="btn btn-outline btn-warning btn-warning">Update</button> 
		</div>
	</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<div>This Route id does not exist</div> 
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>